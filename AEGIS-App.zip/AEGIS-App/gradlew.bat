@rem Gradle start up script for Windows
@IF "%JAVA_HOME%" == "" (
  set JAVA_HOME=C:\Program Files\Java\jdk-17
)
"%JAVA_HOME%\bin\java.exe" -classpath "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
