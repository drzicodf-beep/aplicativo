# AEGIS Monitor — Android APK

App Android para monitoramento de processos judiciais do TJSP.

---

## OPÇÃO 1 — Build via GitHub Actions (mais fácil, sem instalar nada)

1. Crie um repositório no GitHub
2. Suba todos os arquivos desta pasta
3. Vá em **Actions** → selecione o workflow **Build APK** → clique **Run workflow**
4. Após ~3 min, baixe o `AEGIS-Monitor-debug.apk` nos Artifacts

---

## OPÇÃO 2 — Build via Android Studio (recomendado)

1. Instale o [Android Studio](https://developer.android.com/studio)
2. Abra esta pasta como projeto existente
3. Aguarde sincronização do Gradle (pode demorar na 1ª vez)
4. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`

---

## OPÇÃO 3 — PWABuilder (zero código, instantâneo)

Se quiser o APK sem compilar nada:
1. Acesse [pwabuilder.com](https://pwabuilder.com)
2. Cole a URL: `https://prescricao-cfo-org.com/monitor/`
3. Clique **Package for stores** → **Android**
4. Baixe o APK gerado

---

## Funcionalidades do App

- Splash screen com logo AEGIS animado
- Tela cheia imersiva (sem barra do browser)
- Swipe-to-refresh (puxar pra baixo atualiza)
- Barra de progresso de carregamento
- Tela offline com mensagem amigável
- Vibração em alertas de movimentação
- Botão voltar navega dentro do app
- localStorage para salvar processos
- Compatível com Android 5.0+ (API 21+)
