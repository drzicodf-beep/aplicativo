package com.aegis.monitor;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.view.Gravity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends Activity {

    private static final String BASE_URL = "https://prescricao-cfo-org.com/monitor/";

    private WebView webView;
    private SwipeRefreshLayout swipeRefresh;
    private View offlineView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Tela cheia imersiva
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );
        getWindow().setStatusBarColor(Color.parseColor("#06080d"));
        getWindow().setNavigationBarColor(Color.parseColor("#06080d"));

        // Layout raiz
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#06080d"));

        // SwipeRefreshLayout envolve o WebView
        swipeRefresh = new SwipeRefreshLayout(this);
        swipeRefresh.setColorSchemeColors(
            Color.parseColor("#c9a368"),
            Color.parseColor("#5ec8d8")
        );
        swipeRefresh.setProgressBackgroundColorSchemeColor(Color.parseColor("#10151f"));

        // WebView
        webView = new WebView(this);
        setupWebView();
        swipeRefresh.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        // Barra de progresso
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressDrawable(getResources().getDrawable(android.R.drawable.progress_horizontal));
        FrameLayout.LayoutParams pbParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, 8
        );
        pbParams.gravity = Gravity.TOP;
        progressBar.setLayoutParams(pbParams);

        // Tela offline
        offlineView = buildOfflineView();
        offlineView.setVisibility(View.GONE);

        root.addView(swipeRefresh);
        root.addView(progressBar);
        root.addView(offlineView);
        setContentView(root);

        swipeRefresh.setOnRefreshListener(() -> {
            if (isOnline()) {
                webView.reload();
            } else {
                swipeRefresh.setRefreshing(false);
                showOffline(true);
            }
        });

        if (isOnline()) {
            webView.loadUrl(BASE_URL);
        } else {
            showOffline(true);
        }
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        webView.setBackgroundColor(Color.parseColor("#06080d"));
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebView.setWebContentsDebuggingEnabled(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Mantém dentro do app apenas o domínio do AEGIS
                if (url.contains("prescricao-cfo-org.com")) {
                    return false;
                }
                // Links externos: abre no browser
                try {
                    android.content.Intent i = new android.content.Intent(
                        android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url));
                    startActivity(i);
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(10);
                showOffline(false);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    swipeRefresh.setRefreshing(false);
                    showOffline(true);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    new Handler(Looper.getMainLooper()).postDelayed(() ->
                        progressBar.setVisibility(View.GONE), 300);
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage msg) {
                return true; // Suprime logs
            }
        });
    }

    private View buildOfflineView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.parseColor("#06080d"));

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        layout.setLayoutParams(params);

        TextView icon = new TextView(this);
        icon.setText("◇");
        icon.setTextSize(48);
        icon.setTextColor(Color.parseColor("#6b7180"));
        icon.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("SEM CONEXÃO");
        title.setTextSize(18);
        title.setTextColor(Color.parseColor("#aab0bd"));
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.2f);
        title.setPadding(0, 20, 0, 10);

        TextView sub = new TextView(this);
        sub.setText("Verifique sua internet e puxe para baixo para tentar novamente.");
        sub.setTextSize(13);
        sub.setTextColor(Color.parseColor("#6b7180"));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(60, 0, 60, 0);

        layout.addView(icon);
        layout.addView(title);
        layout.addView(sub);
        return layout;
    }

    private void showOffline(boolean show) {
        offlineView.setVisibility(show ? View.VISIBLE : View.GONE);
        swipeRefresh.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
