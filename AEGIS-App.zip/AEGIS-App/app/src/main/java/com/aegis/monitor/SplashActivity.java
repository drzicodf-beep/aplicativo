package com.aegis.monitor;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        );

        // Layout programático — sem dependência de XML de layout
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#06080d"));
        setContentView(root);

        // Diamante ASCII como logo
        TextView diamond = new TextView(this);
        diamond.setText("◆");
        diamond.setTextSize(40);
        diamond.setTextColor(Color.parseColor("#c9a368"));
        diamond.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("AEGIS");
        title.setTextSize(34);
        title.setTextColor(Color.parseColor("#f2f0ea"));
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.3f);
        title.setPadding(0, 16, 0, 8);

        TextView sub = new TextView(this);
        sub.setText("PROCESS INTELLIGENCE");
        sub.setTextSize(11);
        sub.setTextColor(Color.parseColor("#6b7180"));
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.3f);

        root.addView(diamond);
        root.addView(title);
        root.addView(sub);

        // Animação de fade in
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(800);
        root.startAnimation(fadeIn);

        // Vai para a MainActivity após 1.6s
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 1600);
    }
}
